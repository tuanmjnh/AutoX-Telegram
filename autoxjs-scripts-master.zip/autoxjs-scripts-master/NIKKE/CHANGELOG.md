修复以下问题：

- 结束应用失败；
- 爬塔战斗结束后卡住；
- 特拦队伍识别；
- 截图权限申请问题；

新增功能：

- 适配珍藏品派遣，脚本会选择第一个随机派遣，如果需特定妮姬珍藏品，自行在游戏里选好，之后游戏会保存选择结果；
- 出错时将OCR结果保存在文件里；

具体使用方式详见[README](https://github.com/Zebartin/autoxjs-scripts/blob/master/NIKKE/README.md)。
