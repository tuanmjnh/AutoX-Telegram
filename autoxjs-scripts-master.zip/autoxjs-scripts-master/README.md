# autoxjs-scripts

基于[AutoX.js](https://github.com/kkevsekk1/AutoX)的一些脚本

- utils.js: 包括锁屏解锁、请求屏幕截图权限、OCR重试等通用方法
- NIKKE/*.js: 包括日常收菜、冬日活动刷副本+刷小游戏+收菜